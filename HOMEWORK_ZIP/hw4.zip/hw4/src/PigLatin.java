import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PigLatin {
    static List<Character> vowels = Arrays.asList('a', 'e', 'i', 'o', 'u');

    public static String toPigLatin(String input) {

        // Complete here ...

    }

    public static void main(String[] args) {
        List<String> words = List.of("pig", "latin", "smile", "string", "eat");

        System.out.println(words.stream()
                                .map(PigLatin::toPigLatin)
                                .collect(Collectors.toList()));
    }
}

