import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Homework4Test {

    /**
     * Fibonacci Test
     */
    @Test
    void iterative_and_tailrec_results_must_match() {

    }

    @Test
    void should_cause_stack_overflow() {

    }

    /**
     * PigLatin Test
     */
    @Test
    void test_words_starting_with_vowels() {

    }

    @Test
    void test_words_starting_with_consonants() {

    }

    /**
     * Puzzle Test
     */
    @Test
    void extensive_puzzle_test() {

    }

    // More tests ...
}
