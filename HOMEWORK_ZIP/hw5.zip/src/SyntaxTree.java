
public class SyntaxTree extends LinkedBinaryTree<String> {

    public static SyntaxTree buildSyntaxTree(String[] expr) {
        // construct an expression syntax tree ...
    }

    public String parenthesize() {
        // you may define helper recursive method and use it here...
    }

    public double evaluate() {
        // you may define helper recursive method and use it here...
    }

    public String toPrefix() {
        // you may define helper recursive method and use it here...
    }

    public String indentSyntaxTree() {
        // you may define helper recursive method and use it here...
    }

    public static void main(String... args) {
        System.out.println("Homework 5");
    }
}


